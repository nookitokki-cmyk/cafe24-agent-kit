# cafe24-agent-kit (distribution)

Version: v2.4.0 (2026-06-21)
Built: 2026-06-21T09:10:51Z
Source: cafe24-agent-workspace/

## Quick start (4 steps)

1. **의존성** — `cd mcp && pip install -r requirements.txt`
2. **몰 설정** — `mcp/config/cafe24_config.example.py` → `cafe24_config_{몰ID}.py` (CLIENT_ID/SECRET 입력)
3. **Cursor MCP** — `.cursor/mcp.json.example` → `.cursor/mcp.json` 복사 후 Cursor 재시작
4. **OAuth** — `python cli.py auth-url --mall {몰ID}` → 브라우저 허용 → `python cli.py code "oauth-callback?code=..." --mall {몰ID}`

**검증:** `python -c "import server"` · `python cli.py status --mall {몰ID}` · MCP `get_kit_guides`

초보자 가이드: `agent-kit/00_시작하기/05b-MCP-등록.md` · 슬래시 `/키트시작`
GitHub Release: `github.com/nookitokki-cmyk/cafe24-agent-kit` · `python cli.py kit-update --from-github`
번들·제외 목록: `agent-kit/connect/DISTRIBUTION-KIT.md` §2·§4·§7 · `CHANGELOG.md`
